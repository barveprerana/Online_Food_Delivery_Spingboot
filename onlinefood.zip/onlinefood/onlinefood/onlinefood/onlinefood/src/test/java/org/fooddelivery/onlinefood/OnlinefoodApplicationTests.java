package org.fooddelivery.onlinefood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinefoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
